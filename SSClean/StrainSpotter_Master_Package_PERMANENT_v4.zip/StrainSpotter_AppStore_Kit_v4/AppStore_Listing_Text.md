# StrainSpotter — App Store Listing Text
Subtitle: AI-powered strain identifier
Promotional: Identify, organize, and learn about cannabis strains with private on-device AI.
Keywords: Cannabis, Weed, Strains, Identifier, Marijuana, Bud, Recognition, Gallery, CLIP AI
Description: On-device strain identification using open models (CLIP + OCR), private by design. Build a gallery, import/export JSON, and match photos locally.
