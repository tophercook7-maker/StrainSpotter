Phase 0: npm install → npm run dev
Phase 1: npm run build
Phase 2: npm run cap:ios
Phase 3: Xcode Archive → Upload
Phase 4: App Store Connect listing → Submit
