1) npm run cap:ios → opens Xcode
2) Signing & Capabilities → Automatically manage signing → Team
3) General → Bundle ID com.yourco.StrainSpotter → Version 1.0.0 → Build 1
4) Assets.xcassets → add icon set
5) Info.plist (optional) → NSCameraUsageDescription / NSPhotoLibraryUsageDescription
6) Product → Archive → Distribute App → App Store Connect → Upload
